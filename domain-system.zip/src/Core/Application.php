<?php

namespace DomainSystem\Core;

use DomainSystem\Core\Container\Container;
use DomainSystem\Core\Events\EventDispatcher;
use DomainSystem\Core\Plugin\PluginManager;
use DomainSystem\Core\Routing\Router;

class Application
{
    private static ?Application $instance = null;
    
    private Container $container;
    private EventDispatcher $dispatcher;
    private PluginManager $pluginManager;
    private Router $router;

    public function __construct(Container $container, EventDispatcher $dispatcher)
    {
        $this->container = $container;
        $this->dispatcher = $dispatcher;
        $this->pluginManager = new PluginManager($container, $dispatcher);
        $this->router = new Router($container);
        
        self::$instance = $this;

        // Automatically bind itself to the container
        $this->container->singleton(Application::class, function() {
            return $this;
        });
        
        $this->container->singleton(Container::class, function() {
            return $this->container;
        });
        
        $this->container->singleton(EventDispatcher::class, function() {
            return $this->dispatcher;
        });

        $this->container->singleton(Router::class, function() {
            return $this->router;
        });
    }

    public static function getInstance(): ?Application
    {
        return self::$instance;
    }

    public function getContainer(): Container
    {
        return $this->container;
    }

    public function getDispatcher(): EventDispatcher
    {
        return $this->dispatcher;
    }

    public function getPluginManager(): PluginManager
    {
        return $this->pluginManager;
    }

    public function getRouter(): Router
    {
        return $this->router;
    }

    public function boot(): void
    {
        // Load plugins
        $this->pluginManager->bootPlugins();
        
        // Dispatch the init hook, giving plugins a chance to register their components
        $this->dispatcher->dispatch('init');
    }
}
