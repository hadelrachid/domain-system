<?php

echo "Iniciando Instalador de Pacotes do Domain-System...\n";
echo "Pacote: legal_cases (Simulando Extracao ZIP)\n";

$baseDir = dirname(dirname(__DIR__)); // htdocs/domain-system
$sourcePath = $baseDir . "/temp/package_builder/legal_cases";
$extractPath = $baseDir . "/src/Plugins/legal_cases";

// Funcao rudimentar de copia recursiva
function xcopy($source, $dest) {
    if (!is_dir($dest)) mkdir($dest, 0755, true);
    foreach (
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST) as $item
    ) {
        if ($item->isDir()) {
            if (!is_dir($dest . DIRECTORY_SEPARATOR . $iterator->getSubPathname())) {
                mkdir($dest . DIRECTORY_SEPARATOR . $iterator->getSubPathname());
            }
        } else {
            copy($item, $dest . DIRECTORY_SEPARATOR . $iterator->getSubPathname());
        }
    }
}

xcopy($sourcePath, $extractPath);
echo "✔️ Arquivos descompactados com sucesso.\n";

// Atualizar plugins.json
$pluginsConfigPath = $baseDir . "/config/plugins.json";
$config = json_decode(file_get_contents($pluginsConfigPath), true);
$config["legal_cases"] = true; // Ativar o plugin
file_put_contents($pluginsConfigPath, json_encode($config, JSON_PRETTY_PRINT));
echo "✔️ Plugin legal_cases ativado no config/plugins.json.\n";

// Criar usuário Advogado no banco
try {
    $dbPath = $baseDir . "/database.sqlite";
    $pdo = new PDO("sqlite:" . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Checar se já existe
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE email = 'harvey@specter.com'");
    if ($stmt->fetchColumn() == 0) {
        $hash = password_hash("123456", PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO users (name, email, password, role) VALUES ('Dr. Harvey Specter', 'harvey@specter.com', '$hash', 'lawyer')");
        echo "✔️ Usuário Dr. Harvey Specter (lawyer) criado com sucesso.\n";
    } else {
        echo "✔️ Usuário Dr. Harvey Specter já existe.\n";
    }

} catch (Exception $e) {
    echo "Erro de Banco: " . $e->getMessage() . "\n";
}

echo "\nInstalação concluída! Faça login com harvey@specter.com e senha 123456 para acessar o Cockpit Jurídico.\n";

