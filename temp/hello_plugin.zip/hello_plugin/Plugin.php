<?php
namespace DomainSystem\Plugins\hello_plugin;

use DomainSystem\Core\Plugin\AbstractPlugin;
use DomainSystem\Core\Routing\Router;

class Plugin extends AbstractPlugin
{
    public function register(): void
    {
        $events = $this->container->make(\DomainSystem\Core\Events\EventDispatcher::class);
        
        $events->addListener('admin.menu', function($menu) {
            $menu[] = [
                'title' => '👋 Dizer Olá',
                'url' => '/admin/hello',
                'icon' => '✨'
            ];
            return $menu;
        });
        
        $events->addListener('router.register', function(Router $router) {
            $router->addRoute('GET', '/admin/hello', function() {
                echo "<h1>Olá! O plugin está funcionando perfeitamente!</h1>";
                echo "<p>Vá até o arquivo <code>src/Plugins/hello_plugin/Plugin.php</code> e apague um ponto-e-vírgula propositalmente para ver o Disjuntor em ação!</p>";
            });
        });
    }
}
